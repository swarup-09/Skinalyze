import os
import json
import numpy as np
import tensorflow as tf
import cv2
import base64
from tensorflow.keras.preprocessing import image
from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
from io import BytesIO


MODEL_PATH = r"D:\KIT\Projects\skin_disease_project\models\skin_disease_model_mobilenetv2.h5"
TRAIN_DIR = r"D:\KIT\Projects\skin_disease_project\dataset_split\train"
DISEASE_INFO_PATH = "disease_info.json" 
IMAGE_SIZE = (224, 224)
CONFIDENCE_THRESHOLD = 0.50
try:
    model = tf.keras.models.load_model(MODEL_PATH)
   
    CLASS_NAMES = sorted([f for f in os.listdir
     (TRAIN_DIR) if os.path.isdir(os.path.join(TRAIN_DIR, f))])
    with open(DISEASE_INFO_PATH, 'r') as f:
        DISEASE_INFO = json.load(f)

    BASE_MODEL = model.layers[0]  # MobileNetV2
    HEAD_MODEL = tf.keras.Sequential(model.layers[1:])  # Remaining layers
    LAST_CONV_LAYER_NAME = 'Conv_1' 

    try:
        BASE_MODEL.get_layer(LAST_CONV_LAYER_NAME)
    except ValueError:
        print(f"Warning: Layer '{LAST_CONV_LAYER_NAME}' not found in the base model. Grad-CAM may fail.")

except Exception as e:
    print(f"Error loading resources: {e}")
    raise RuntimeError(f"Failed to load required ML resources. Check paths and model image. Error: {e}")


class DiseaseResponse(BaseModel):
    """Defines the structure of the JSON response, including the base64 image."""
    success: bool
    predicted_disease: str
    confidence: float
    cause: str
    precautions: List[str]
    grad_cam_image_base64: str 

# FastAPI App Initialization 

app = FastAPI(
    title="Skin Disease Prediction API",
    description="API for predicting skin diseases from images and providing related info and Grad-CAM visualization.",
    version="1.1.0"
)

# --- Utility Functions ---

def load_and_preprocess_image(file_content: bytes) -> tuple[np.ndarray, np.ndarray]:
    """
    Loads raw image image (bytes), preprocesses it for the model, and returns
    both the preprocessed array and the original BGR image for blending.
    """
    try:
        img = image.load_img(BytesIO(file_content), target_size=IMAGE_SIZE)
        img_array = image.img_to_array(img) / 255.0
        img_array_expanded = np.expand_dims(img_array, axis=0)

        np_arr = np.frombuffer(file_content, np.uint8)
        orig_img_cv = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        orig_img_cv_resized = cv2.resize(orig_img_cv, IMAGE_SIZE)
        
        return img_array_expanded, orig_img_cv_resized
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid image image format or processing error: {e}")

def get_disease_info(disease_name: str) -> Dict[str, Any]:
    """Retrieves cause and precautions from the loaded JSON data."""
    info = DISEASE_INFO.get(disease_name, {})
    return {
        "cause": info.get("cause", "Information not available."),
        "precautions": info.get("precautions", ["Information not available."])
    }

def generate_grad_cam_overlay_base64(img_array: np.ndarray, orig_img_cv: np.ndarray, predicted_class_index: int) -> str:
    """
    Generates the Grad-CAM heatmap, overlays it on the original image,
    and returns the resulting image encoded as a base64 string.
    """
    try:
        grad_model = tf.keras.models.Model(
            inputs=BASE_MODEL.input,
            outputs=[BASE_MODEL.get_layer(LAST_CONV_LAYER_NAME).output, BASE_MODEL.output]
        )

        with tf.GradientTape() as tape:
            conv_outputs, predictions = grad_model(img_array)
            predictions = HEAD_MODEL(predictions)
            loss = predictions[:, predicted_class_index]

        grads = tape.gradient(loss, conv_outputs)
        pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
        conv_outputs = conv_outputs[0] * pooled_grads

        heatmap = np.mean(conv_outputs, axis=-1)
        heatmap = np.maximum(heatmap, 0)
        heatmap /= (np.max(heatmap) + 1e-8) 

        heatmap_resized = cv2.resize(heatmap, IMAGE_SIZE)
        heatmap_color = cv2.applyColorMap(np.uint8(255 * heatmap_resized), cv2.COLORMAP_JET)

        overlay = cv2.addWeighted(orig_img_cv, 0.6, heatmap_color, 0.4, 0)

        _, buffer = cv2.imencode('.png', overlay)
        base64_encoded_image = base64.b64encode(buffer).decode('utf-8')
        
        return base64_encoded_image

    except Exception as e:
        print(f"Error during Grad-CAM generation: {e}")
        return ""


# --- API Endpoints ---
@app.post("/predict", response_model=DiseaseResponse)
async def predict_disease(image: UploadFile = File(...)):
    """
    Accepts an image image, predicts the skin disease, generates Grad-CAM,
    and returns the prediction, info, and the base64 Grad-CAM image.
    """
    file_content = await image.read()
    img_array, orig_img_cv = load_and_preprocess_image(file_content)

    pred = model.predict(img_array)[0] 
    predicted_class_index = np.argmax(pred)
    confidence = float(pred[predicted_class_index])
    
    # --- 💡 NEW LOGIC: Confidence Threshold Check ---
    if np.sum(pred) == 0:
        raise HTTPException(status_code=500, detail="Model returned zero prediction. Check model integrity.")
        
    if confidence < CONFIDENCE_THRESHOLD:
        # If the highest probability is too low, assume no significant disease
        return {
            "success": False,
            "predicted_disease": "No Significant Disease Detected",
            "confidence": round(confidence * 100, 2),
            "cause": "Model confidence is below the set threshold. The image may represent healthy skin or a condition not included in the model's training set.",
            "precautions": ["Monitor the area and consult a healthcare professional for a definitive diagnosis.", "Ensure proper skin hygiene."],
            "grad_cam_image_base64": "" # Return an empty string or a placeholder image
        }
    # --- 💡 END NEW LOGIC ---

    # --- Existing Logic for a confident prediction ---
    predicted_disease = CLASS_NAMES[predicted_class_index]
    
    # Grad-CAM is only generated for a high-confidence disease prediction
    base64_image = generate_grad_cam_overlay_base64(
        img_array, 
        orig_img_cv, 
        predicted_class_index
    )

    info = get_disease_info(predicted_disease)

    return {
        "success": True,
        "predicted_disease": predicted_disease,
        "confidence": round(confidence * 100, 2),
        "cause": info["cause"],
        "precautions": info["precautions"],
        "grad_cam_image_base64": base64_image 
    }

@app.get("/")
def health_check():
    """Basic health check to verify the API is running."""
    return {"status": "ok", "message": "Skin Disease Prediction API is running."}

#To Host(run) :  uvicorn gradcam_API:app --host 0.0.0.0 --port 8000